using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Threading;

// Task 3.2 — Сервер для работы с файлами-изображениями
// Принимает изображение от клиента (8 байт размер + данные),
// уменьшает его вдвое, возвращает (8 байт размер + данные).
// Обрабатывает несколько клиентов одновременно.
// Требует NuGet-пакет: System.Drawing.Common

class Program
{
    static void Main()
    {
        TcpListener listener = new TcpListener(IPAddress.Any, 5002);
        listener.Start();
        Console.WriteLine("[Server] Listening on port 5002...");

        while (true)
        {
            TcpClient client = listener.AcceptTcpClient();
            Thread t = new Thread(() => HandleClient(client));
            t.IsBackground = true;
            t.Start();
        }
    }

    static void HandleClient(TcpClient client)
    {
        Console.WriteLine("[Server] Client connected.");
        using (client)
        using (NetworkStream stream = client.GetStream())
        {
            try
            {
                // --- Шаг 1: читаем 8 байт — размер входящего изображения ---
                byte[] sizeBuffer = ReadExact(stream, 8);
                long imageSize = BitConverter.ToInt64(sizeBuffer, 0);
                Console.WriteLine($"[Server] Expecting image of {imageSize} bytes.");

                // --- Шаг 2: читаем ровно imageSize байт ---
                byte[] imageBuffer = ReadExact(stream, (int)imageSize);
                Console.WriteLine("[Server] Image received. Resizing...");

                // --- Шаг 3: уменьшаем изображение вдвое (код из задания) ---
                byte[] resizedBytes;
                using (var inputStream = new MemoryStream(imageBuffer))
                using (var originalImage = new Bitmap(inputStream))
                {
                    int newWidth = originalImage.Width / 2;
                    int newHeight = originalImage.Height / 2;

                    using var resizedImage = new Bitmap(newWidth, newHeight);
                    using (var graphics = Graphics.FromImage(resizedImage))
                    {
                        graphics.InterpolationMode = InterpolationMode.HighQualityBicubic;
                        graphics.DrawImage(originalImage, 0, 0, newWidth, newHeight);
                    }

                    using var outputStream = new MemoryStream();
                    resizedImage.Save(outputStream, ImageFormat.Jpeg);
                    resizedBytes = outputStream.ToArray();
                }

                Console.WriteLine($"[Server] Resized image size: {resizedBytes.Length} bytes. Sending back...");

                // --- Шаг 4: отправляем 8 байт размера, затем данные ---
                byte[] responseSizeBytes = BitConverter.GetBytes((long)resizedBytes.Length);
                stream.Write(responseSizeBytes, 0, 8);
                stream.Write(resizedBytes, 0, resizedBytes.Length);
                Console.WriteLine("[Server] Response sent.");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"[Server] Error: {ex.Message}");
            }
        }

        Console.WriteLine("[Server] Client disconnected.");
    }

    /// <summary>
    /// Читает ровно count байт из потока. Необходимо, потому что
    /// stream.Read() не гарантирует, что вернёт сразу все запрошенные байты.
    /// </summary>
    static byte[] ReadExact(NetworkStream stream, int count)
    {
        byte[] buffer = new byte[count];
        int offset = 0;
        while (offset < count)
        {
            int read = stream.Read(buffer, offset, count - offset);
            if (read == 0) throw new Exception("Connection closed unexpectedly.");
            offset += read;
        }
        return buffer;
    }
}
