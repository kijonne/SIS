using System;
using System.IO;
using System.Net.Sockets;

// Task 3.1 — Клиент для отправки изображения на сервер
// Запрашивает путь к файлу, отправляет (8 байт размер + данные),
// получает обратно уменьшенное изображение и сохраняет рядом с оригиналом.

class Program
{
    static void Main()
    {
        Console.Write("Enter image file path (e.g. C:\\photo.jpg): ");
        string filePath = Console.ReadLine()?.Trim();

        if (!File.Exists(filePath))
        {
            Console.WriteLine("[Client] File not found.");
            return;
        }

        byte[] imageBytes = File.ReadAllBytes(filePath);
        Console.WriteLine($"[Client] File size: {imageBytes.Length} bytes. Connecting...");

        using TcpClient client = new TcpClient("127.0.0.1", 5002);
        using NetworkStream stream = client.GetStream();
        Console.WriteLine("[Client] Connected. Sending image...");

        // --- Шаг 1: отправляем 8 байт с размером файла ---
        byte[] sizeBytes = BitConverter.GetBytes((long)imageBytes.Length);
        stream.Write(sizeBytes, 0, 8);

        // --- Шаг 2: отправляем сами байты изображения ---
        stream.Write(imageBytes, 0, imageBytes.Length);
        Console.WriteLine("[Client] Image sent. Waiting for response...");

        // --- Шаг 3: читаем 8 байт — размер ответного файла ---
        byte[] responseSizeBuffer = ReadExact(stream, 8);
        long responseSize = BitConverter.ToInt64(responseSizeBuffer, 0);
        Console.WriteLine($"[Client] Incoming resized image: {responseSize} bytes.");

        // --- Шаг 4: читаем ровно responseSize байт ---
        byte[] resizedBytes = ReadExact(stream, (int)responseSize);

        // --- Шаг 5: сохраняем файл рядом с оригиналом ---
        string dir = Path.GetDirectoryName(filePath) ?? ".";
        string name = Path.GetFileNameWithoutExtension(filePath);
        string savePath = Path.Combine(dir, name + "_resized.jpg");
        File.WriteAllBytes(savePath, resizedBytes);

        Console.WriteLine($"[Client] Saved resized image to: {savePath}");
    }

    /// <summary>
    /// Читает ровно count байт из потока.
    /// </summary>
    static byte[] ReadExact(NetworkStream stream, int count)
    {
        byte[] buffer = new byte[count];
        int offset = 0;
        while (offset < count)
        {
            int read = stream.Read(buffer, offset, count - offset);
            if (read == 0) throw new Exception("Connection closed unexpectedly.");
            offset += read;
        }
        return buffer;
    }
}
