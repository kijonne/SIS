using System;
using System.Net.Sockets;
using System.Text;

// Task 2.1 — ConsoleClient
// Спрашивает имя пользователя, отправляет его на сервер,
// затем в цикле читает ввод и отправляет сообщения.
// Введите "exit" для выхода.

class Program
{
    static void Main()
    {
        TcpClient client = new TcpClient("127.0.0.1", 5001);
        NetworkStream stream = client.GetStream();
        Console.WriteLine("[Client] Connected to server.");

        // Запрашиваем имя и сразу отправляем его серверу
        Console.Write("Enter your username: ");
        string username = Console.ReadLine();
        SendMessage(stream, "USERNAME:" + username);

        Console.WriteLine("Type a message and press Enter to send. Type 'exit' to quit.");

        while (true)
        {
            string input = Console.ReadLine();
            if (input?.ToLower() == "exit") break;

            if (!string.IsNullOrEmpty(input))
                SendMessage(stream, "MSG:" + input);
        }

        client.Close();
        Console.WriteLine("[Client] Disconnected.");
    }

    static void SendMessage(NetworkStream stream, string message)
    {
        byte[] data = Encoding.UTF8.GetBytes(message);
        stream.Write(data, 0, data.Length);
    }
}
