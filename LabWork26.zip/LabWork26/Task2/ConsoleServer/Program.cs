using System;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;

// Task 2.2 — ConsoleServer
// Принимает подключения от нескольких клиентов одновременно (каждый в своём потоке).
// Выводит: ИмяКлиента (чч:мм:сс дд.мм.гггг): текст

class Program
{
    static void Main()
    {
        TcpListener listener = new TcpListener(IPAddress.Any, 5001);
        listener.Start();
        Console.WriteLine("[Server] Listening on port 5001...");

        while (true)
        {
            // Ждём нового клиента; каждый обрабатывается в отдельном потоке
            TcpClient client = listener.AcceptTcpClient();
            Thread t = new Thread(() => HandleClient(client));
            t.IsBackground = true; // поток завершится вместе с процессом
            t.Start();
        }
    }

    static void HandleClient(TcpClient client)
    {
        using (client)
        using (NetworkStream stream = client.GetStream())
        {
            byte[] buffer = new byte[4096];
            string username = null;

            while (true)
            {
                int bytesRead;
                try
                {
                    bytesRead = stream.Read(buffer, 0, buffer.Length);
                }
                catch
                {
                    break; // клиент отключился
                }

                if (bytesRead == 0) break;

                string received = Encoding.UTF8.GetString(buffer, 0, bytesRead);

                // Протокол: первое сообщение — имя пользователя (префикс "USERNAME:")
                //           последующие — текст (префикс "MSG:")
                if (received.StartsWith("USERNAME:"))
                {
                    username = received.Substring("USERNAME:".Length).Trim();
                    Console.WriteLine($"[Server] New user connected: {username}");
                }
                else if (received.StartsWith("MSG:") && username != null)
                {
                    string text = received.Substring("MSG:".Length).Trim();
                    string timestamp = DateTime.Now.ToString("HH:mm:ss dd.MM.yyyy");
                    // Формат вывода: Имя (чч:мм:сс дд.мм.гггг): текст
                    Console.WriteLine($"{username} ({timestamp}): {text}");
                }
            }

            if (username != null)
                Console.WriteLine($"[Server] User disconnected: {username}");
        }
    }
}
