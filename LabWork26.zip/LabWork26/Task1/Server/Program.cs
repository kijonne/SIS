using System;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;

// Task 1.2 — Сервер, отправляющий сообщение клиенту каждые 5 секунд
// Ожидает подключение одного клиента, затем шлёт ему сообщения в бесконечном цикле.

class Program
{
    static void Main()
    {
        // Слушаем на всех интерфейсах, порт 5000
        TcpListener listener = new TcpListener(IPAddress.Any, 5000);
        listener.Start();
        Console.WriteLine("[Server] Listening on port 5000...");

        // Принимаем одного клиента (блокирующий вызов)
        TcpClient client = listener.AcceptTcpClient();
        Console.WriteLine("[Server] Client connected.");

        NetworkStream stream = client.GetStream();

        int counter = 1;
        while (true)
        {
            string message = $"Message #{counter++} from server at {DateTime.Now:HH:mm:ss}";
            byte[] data = Encoding.UTF8.GetBytes(message);
            stream.Write(data, 0, data.Length);
            Console.WriteLine($"[Server] Sent: {message}");
            Thread.Sleep(5000); // пауза 5 секунд
        }
    }
}
