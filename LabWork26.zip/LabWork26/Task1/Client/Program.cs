using System;
using System.Net.Sockets;
using System.Text;

// Task 1.1 — Клиент, читающий данные из потока сервера
// Подключается к серверу на localhost:5000 и выводит всё, что приходит.

class Program
{
    static void Main()
    {
        // Подключаемся к серверу
        TcpClient client = new TcpClient("127.0.0.1", 5000);
        Console.WriteLine("[Client] Connected to server.");

        NetworkStream stream = client.GetStream();
        byte[] buffer = new byte[1024];

        while (true)
        {
            // Читаем очередное сообщение от сервера
            int bytesRead = stream.Read(buffer, 0, buffer.Length);
            if (bytesRead == 0)
            {
                Console.WriteLine("[Client] Server disconnected.");
                break;
            }

            string message = Encoding.UTF8.GetString(buffer, 0, bytesRead);
            Console.WriteLine($"[Client] Received: {message}");
        }

        client.Close();
    }
}
